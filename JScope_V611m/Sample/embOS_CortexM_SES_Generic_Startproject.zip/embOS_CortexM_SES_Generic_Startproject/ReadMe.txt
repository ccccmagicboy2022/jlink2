ReadMe.txt for the generic CMSIS start project.

This project was built for Segger Embedded Studio V2.16a.

Supported hardware:
===================
The sample project is prepared to run in the Embedded Studio
simulator. The sample project can also be used to run in hardware,
however, please note that the memory configuration has to be changed
to the target's specification.

Configurations:
===============
- Debug:
  This configuration is prepared for running in the simulator.
  An embOS debug and profiling library is used.

- Release:
  This configuration is prepared for running in the simulator.
  An embOS release library is used.
